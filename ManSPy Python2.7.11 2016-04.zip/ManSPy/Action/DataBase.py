# -*- coding: utf-8 -*-

___list_FASIF = ["""
BBB
antonimo
AAA
BBB estas antonino de AAA
"""]
