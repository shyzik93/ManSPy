# -*- coding: utf-8 -*-

circumstanceDict = {
  'rapid': ['fast', 'speed'],
  'malrapid': ['slow', 'speed']
  }
